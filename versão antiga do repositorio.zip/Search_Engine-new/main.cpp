#include <dirent.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <map>
#include <set>
#include <utility>
#include <cmath>

using namespace std;

struct documento
{
    map <string, int> tf;
    string diretorio;
};

typedef struct documento documento;

class ind_inv{
    public:
    	//Contrutor padr�o do objeto ind_inv
        ind_inv();
        /*Declara que um novo documento ser� inserido no indice invertido e cria um struct
        documento alocado dinamicamente, armazenando at� que o documento seja fechado*/
        void novo_documento(string local);
    	//Insere o ponteiro  documento aberto no indice invertido
        /*Pr�-requisito : A fun��o novo_documento tem que ser chamada para a constru��o do struct
        documento, ou seja, algum documento tem que estar aberto*/
        void inserir_no_indice(const string palavra);
        //Icrementa 1 no tf do documento aberto e retorna true se o documento atual j� foi inserido no indice invertido no pair da palavra do argumento e false se n�o foi
        /*Pr�-requisito : A fun��o novo_documento tem que ser chamada para a
        constru��o do struct documento, ou seja, algum documento tem que estar aberto*/
        bool tf_plus(string palavra);
        //fecha o documento que estava sendo inserido, anulando o ponteiro que estava armazenando o documento aberto
        void fechar_documento();
        //Calcula o idf com base no set<documentos*> do indice invertido e do numero total de arquivos
        /*OBS: essa fun��o pode ser chamado em qualquer parte do programa, porem s� ter� seus valores verdadeiros ap�s a
        leitura de todos os arquivos de uma cole��o*/
        void calculo_idf();
        //retorna o idf para ranquear a pesquisa
        map <string, double> get_idf();
        //retorna um conjunto de ponteiros dos structs documento
        set<documento*> pesquisa (vector<string> pesquisa);
        //Imprime o imdice e o idf
        void imprimir_indice();
        void imprimir_idf();
        //destrutor do objeto da classe
        ~ind_inv();
    private:
        //armazena o indice invertido
        map <string, set <documento*>> indice_invertido;
        //armazena o idf da cole��o
        map <string, double> idf;
        //ponteiro usado para inserir um struct documento, alocado dinamicamente,
        //no indice invertido
        documento* provisorio;
        //guarda o numero de arquivos abertos e armazenados no indice
        int num_arquivos_;
};

class Varredura{
    private:
    int i = 0;
    DIR *dir; // Variavel do tipo diretorio
    struct dirent *lsdir;  // Struct da biblioteca dirent.h
    vector <string> documentos;

    public:
        void inicializa();
        vector <string> setdocumentos();

};

class Tratamento{
    ifstream arquivos;
    string palavra;
    char letra;
    int i;

    public:
        void leitura_palavra(vector <string> documentos, ind_inv &colecao);

};


int main(void)
{

    Varredura inicio; //Cria objeto para varredura dos arquivos no diretorio
    Tratamento palavras; //Cria objeto para tratamento das palavras
    ind_inv colecao; //Cria objeto do indice invertido
    inicio.inicializa(); //Inicializa varredura
    palavras.leitura_palavra(inicio.setdocumentos(),colecao); //Envia todos os documentos para tratamento
    colecao.calculo_idf();//Calcula o idf depois de ter lido todos os atquivos
    //duas funcoes para imprimir o indice e o idf
    //talvez nao seja necessario
    colecao.imprimir_idf();
    colecao.imprimir_indice();
    return 0;

}

//-------------------------------------------------------------- Modulo Inicialização -----------------------------------------------------------------------------------------------

/* A função inicializar acha todos os arquivos para leitura e chama a leitura_palavra para criar o indice invertido */
void Varredura::inicializa(){

    cout << "Iniciando carregamento do Banco de Dados......" << endl << endl; //MOstrar inicio da varredura
    dir = opendir("D:\\arquivos testes"); //Abre a pasta - colocar variavel

    /* Loop para identificar e armazenar temporariamente os arquivos da pasta*/
    while ((lsdir = readdir(dir)) != NULL ){
        string caminho = "D:\\arquivos testes\\";
        caminho = caminho + lsdir->d_name; //Junta o nome do arquivo com o diretorio especificado
        documentos.push_back(caminho); //Coloca a localização desse arquivo no vector
        i++;
    }
    closedir(dir); // Fecha diretorio
}

//-------------------------------------------------------------- Modulo Inicialização - Fim  -----------------------------------------------------------------------------------------------

//-------------------------------------------------------------- Modulo tratamento -----------------------------------------------------------------------------------------------

void Tratamento::leitura_palavra(vector <string> documentos, ind_inv &colecao){
    for(i=0; i < documentos.size(); i++){ //Loop para acessar todos os documentos
        arquivos.open(documentos.at(i)); // Abre o arquivo

        if(!arquivos.is_open()){
            cout << "Nao foi possivel abrir o arquivo" << endl;
        }else{
            colecao.novo_documento(documentos.at(i));
            while(arquivos.get(letra)){ // Loop de formatação, pega letra por letra

                if((letra >= 97 && letra <=122) || (letra >= 48 && letra <=57)){ // Pega as letras minusculas e numeros - ASCII
                    palavra = palavra + letra; // Junta as letras na string
                    continue;
                }

                if(letra >= 65 && letra <=90){ //Pega as letras maiusculas e transforma em minusculas - ASCII
                    letra += 32; //Pela tabela ASCII transforma em minusculo
                    palavra = palavra + letra; // Junta as letras na string
                    continue;
                }

                if(letra == 32){ //Olha se tem espaço " " para finalizar a palavra

                    if(palavra.size() == 0){ //Caso a palavra esteja vazia não faça nada
                        continue;
                    }else{
                        palavra = palavra + '\0'; //Sinaliza final da string palavra
                        colecao.inserir_no_indice(palavra);
                        //cout << palavra << " " ;
                        palavra = "";
                    }
                    continue;
                }

                if(letra == '\n'){ // Olha se acabou a linha
                    //cout << palavra << endl;
                    palavra = palavra + '\0'; //Sinaliza fim da string palavra
                    colecao.inserir_no_indice(palavra);
                    palavra = "";
                }
            }
        }
        colecao.fechar_documento();
        arquivos.close(); // Fecha arquivo antes de abrir outro
    }
    documentos.clear(); // Apaga a memoria dinamica
    cout << "....... Terminado carregamento do Banco de Dados." << endl << endl;
}
//-------------------------------------------------------------- Modulo tratamento - Fim -----------------------------------------------------------------------------------------------


//--------------------------------------------------------------- Modulo Retorna documentos --------------------------------------------------------------------------------------------------

vector <string> Varredura::setdocumentos(){
    return documentos; //Retorna o nome do documento
};

//--------------------------------------------------------------- Fim do Modulo Retorna Documentos ------------------------------------------------------------------------------------------

//-------------------------------------------------------------- Modulo Indice Invertido -----------------------------------------------------------------------------------------------

ind_inv::ind_inv()
{
    num_arquivos_ = 0;
    provisorio = nullptr;
    map <string, set <documento*>> qualquer1;
    map <string, double> qualquer2;
    indice_invertido = qualquer1;
    idf = qualquer2;
}

void ind_inv::novo_documento(string local)
{
    provisorio = new documento;
    provisorio -> diretorio = local;
    num_arquivos_ ++;
}

void ind_inv::inserir_no_indice(const string palavra)
{
    bool incluso;
    incluso = tf_plus(palavra);
    if(!(incluso)){
        std::map<string, set <documento*>>::iterator i;
        i = indice_invertido.find(palavra);
        if (i == indice_invertido.end())
        {
            set<documento*> aux;
            aux.insert(provisorio);
            indice_invertido.insert(make_pair(palavra,aux));
        }
        else{
            i -> second.insert(provisorio);
        }
    }
}

bool ind_inv::tf_plus(string palavra)
{
    std::map<string,int>::iterator i;
    i = provisorio -> tf.find(palavra);
    if (i == provisorio -> tf.end())
    {
        provisorio -> tf.insert(make_pair(palavra,1));
        return false;
    }
    else
    {
        i -> second++;
        return true;
    }
}

void ind_inv::fechar_documento()
{
    provisorio = nullptr;
}

void ind_inv::calculo_idf()
{
	double aux, numdoc = num_arquivos_;
	if (!(idf.empty()))
        idf.clear();
	for (auto i : indice_invertido){
		aux = log(numdoc/i.second.size());
		idf.insert(make_pair(i.first, aux));
	}
}

set<documento*> ind_inv::pesquisa(vector <string> pesquisa)
{
    set<documento*> resultado;
    for (auto i: indice_invertido){
        for (auto j : i.second)
            resultado.insert(j);
    }
    return resultado;
}

ind_inv::~ind_inv()
{
    vector <string> palavras_colecao;
    set <documento*> colecao;
    for (auto i : indice_invertido){
        palavras_colecao.push_back(i.first);
    }
    colecao = pesquisa(palavras_colecao);
    for (auto i : colecao)
        delete i;
    indice_invertido.clear();
}

void ind_inv::imprimir_indice()
{
    for(auto i : indice_invertido){
        cout << i.first << " - {";
        for(auto j : i.second){
            std::size_t nome = j -> diretorio.find_last_of("\\");
            string temporaria = j -> diretorio.substr(nome+1);
            cout << temporaria << "   ";
        }
        cout << "}" << endl;
    }
}

void ind_inv::imprimir_idf()
{
    for (auto i : idf)
        cout << i.first << " - " << i.second << endl;
    cout << endl;
}

//-------------------------------------------------------------- Modulo Indice Invertido - Fim  ----------------------------------------------------------------------------------------------


